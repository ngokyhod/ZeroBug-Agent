/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.cardlayout;

/**
 *
 * @author hoa23
 */
public class Cardlayout {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
